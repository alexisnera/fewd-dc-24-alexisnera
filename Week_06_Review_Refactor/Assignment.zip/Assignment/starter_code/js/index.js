
// Set function to fire when user selects an option/value

	// Use .append to add DOM tag options in select tag

	

	// Create an array with the following values: NYC, SF, LA, ATX, SYD

	// Use a for loop to add values to the <select> menu



	// Create an image variable containing an array of all city images

	// Create a variable that is equivalent to 0

	// Create a variable that will define the maximum amount of images



	// Apply conditionals

		// Use .attr() to change body background url according to selection




// Main
jQuery(document).ready(function(){

	// Indicate function to get starting value .val() of select tag with id #city-type

	// Value will update when user selects an option - use .change()
		
		// Create variable containing value of #city-type

		// Create function that will "hold" variable containing value of user selected option
	
})